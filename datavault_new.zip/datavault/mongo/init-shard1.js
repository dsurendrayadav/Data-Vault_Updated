rs.initiate({
  _id: "shard1RS",
  members: [
    { _id: 0, host: "mongo-shard1:27018" }
  ]
});
