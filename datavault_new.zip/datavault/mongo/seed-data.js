// Seeds the sharded "events" and "products" collections with enough
// documents to spread across all 3 shards and produce a visible,
// slightly-imbalanced chunk distribution for the dashboard to graph.

db = db.getSiblingDB("datavault");

const categories = ["electronics", "home", "toys", "grocery", "apparel", "sports"];
const eventTypes = ["page_view", "add_to_cart", "checkout", "search", "signup"];

// --- products ---------------------------------------------------------
let productBatch = [];
for (let i = 0; i < 20000; i++) {
  productBatch.push({
    sku: "SKU-" + i,
    name: "Product " + i,
    category: categories[i % categories.length],
    price: Math.round((Math.random() * 200 + 5) * 100) / 100,
    stock: Math.floor(Math.random() * 500),
    createdAt: new Date(Date.now() - Math.random() * 1000 * 60 * 60 * 24 * 365)
  });
  if (productBatch.length === 1000) {
    db.products.insertMany(productBatch);
    productBatch = [];
  }
}
if (productBatch.length) db.products.insertMany(productBatch);

// --- events -------------------------------------------------------------
let eventBatch = [];
for (let i = 0; i < 100000; i++) {
  eventBatch.push({
    type: eventTypes[Math.floor(Math.random() * eventTypes.length)],
    userId: "user_" + Math.floor(Math.random() * 8000),
    sku: "SKU-" + Math.floor(Math.random() * 20000),
    ts: new Date(Date.now() - Math.random() * 1000 * 60 * 60 * 24 * 90),
    meta: { source: Math.random() > 0.5 ? "mobile" : "web" }
  });
  if (eventBatch.length === 2000) {
    db.events.insertMany(eventBatch);
    eventBatch = [];
  }
}
if (eventBatch.length) db.events.insertMany(eventBatch);

print(">>> seeded products: " + db.products.countDocuments());
print(">>> seeded events: " + db.events.countDocuments());
