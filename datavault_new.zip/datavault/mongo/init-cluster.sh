#!/bin/bash
set -e

echo ">>> [mongo-setup] waiting for all mongod/mongos processes to come up..."
sleep 10

echo ">>> [mongo-setup] initiating config server replica set"
mongosh --host mongo-configsvr --port 27019 --file /scripts/init-configsvr.js

echo ">>> [mongo-setup] initiating shard1 replica set"
mongosh --host mongo-shard1 --port 27018 --file /scripts/init-shard1.js

echo ">>> [mongo-setup] initiating shard2 replica set"
mongosh --host mongo-shard2 --port 27018 --file /scripts/init-shard2.js

echo ">>> [mongo-setup] initiating shard3 replica set"
mongosh --host mongo-shard3 --port 27018 --file /scripts/init-shard3.js

echo ">>> [mongo-setup] waiting for replica sets to elect primaries..."
sleep 15

echo ">>> [mongo-setup] adding shards to the router + enabling sharding"
mongosh --host mongo-router --port 27017 --file /scripts/init-mongos.js

echo ">>> [mongo-setup] seeding sample sharded collection"
mongosh --host mongo-router --port 27017 --file /scripts/seed-data.js

echo ">>> [mongo-setup] cluster ready"
