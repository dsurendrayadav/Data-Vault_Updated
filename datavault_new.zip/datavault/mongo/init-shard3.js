rs.initiate({
  _id: "shard3RS",
  members: [
    { _id: 0, host: "mongo-shard3:27018" }
  ]
});
