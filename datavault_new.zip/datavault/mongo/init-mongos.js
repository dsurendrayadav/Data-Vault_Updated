// Adds each replica-set shard to the cluster, enables sharding on the
// "datavault" database, and shards two collections so the dashboard's
// shard-balance view has real chunk distribution to report on.

sh.addShard("shard1RS/mongo-shard1:27018");
sh.addShard("shard2RS/mongo-shard2:27018");
sh.addShard("shard3RS/mongo-shard3:27018");

sh.enableSharding("datavault");

// Hashed shard key on _id gives an even, self-balancing distribution —
// good for the "shard balance" panel to visualize real rebalancing.
db = db.getSiblingDB("datavault");

db.createCollection("events");
sh.shardCollection("datavault.events", { _id: "hashed" });

db.createCollection("products");
sh.shardCollection("datavault.products", { sku: "hashed" });

print(">>> shards added and collections sharded");
