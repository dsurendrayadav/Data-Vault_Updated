rs.initiate({
  _id: "shard2RS",
  members: [
    { _id: 0, host: "mongo-shard2:27018" }
  ]
});
