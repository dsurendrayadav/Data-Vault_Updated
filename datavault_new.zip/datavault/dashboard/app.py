"""
DataVault — multi-database operations dashboard
Streamlit + psycopg2 + pymongo

Tabs:
  1. Overview               - cluster topology + health at a glance
  2. PostgreSQL Slow Queries - pg_stat_statements ranked by mean exec time
  3. Index Recommendations   - EXPLAIN-driven CREATE INDEX suggestions
  4. Replication Lag         - primary -> replica streaming lag
  5. MongoDB Shard Balance   - chunk distribution across the 3 shards
  6. MongoDB Server Status   - serverStatus() + per-shard replica health
  7. Runbook                 - backup/PITR + failover docs, rendered inline
"""

import os
import streamlit as st
import pandas as pd
import plotly.express as px

import pg_monitor as pgm
import mongo_monitor as mgm
import query_optimizer as qo

st.set_page_config(page_title="DataVault", layout="wide", page_icon="🗄️")

st.title("🗄️ DataVault")
st.caption("Multi-database operations dashboard — PostgreSQL replication + MongoDB sharding")

tabs = st.tabs([
    "Overview",
    "PostgreSQL Slow Queries",
    "Index Recommendations",
    "Replication Lag",
    "MongoDB Shard Balance",
    "MongoDB Server Status",
    "Runbook",
])

# ---------------------------------------------------------------------------
# Shared connections (cached so we don't reconnect on every rerun)
# ---------------------------------------------------------------------------
@st.cache_resource(ttl=30)
def pg_primary():
    return pgm.get_primary_conn()

@st.cache_resource(ttl=30)
def mongo_client():
    return mgm.get_client()


def safe(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs), None
    except Exception as e:
        return None, str(e)


# ===========================================================================
# TAB 1 — Overview
# ===========================================================================
with tabs[0]:
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("PostgreSQL cluster")
        st.markdown("""
- **pg-primary** — read/write, streams WAL to 2 replicas, WAL-archives for PITR
- **pg-replica1 / pg-replica2** — hot standbys, streaming replication, `hot_standby=on`
        """)
        conn, err = safe(pg_primary)
        if err:
            st.error(f"Cannot reach primary: {err}")
        else:
            df, err = safe(pgm.get_replication_lag, conn)
            if err:
                st.warning(err)
            elif df is not None and not df.empty:
                st.metric("Connected replicas", len(df))
            else:
                st.info("No replicas currently streaming (check docker compose logs).")

    with col2:
        st.subheader("MongoDB cluster")
        st.markdown("""
- **mongo-configsvr** — config server replica set (cluster metadata)
- **mongo-shard1/2/3** — 3 shard replica sets holding the sharded data
- **mongo-router (mongos)** — query router the dashboard/app connects to
        """)
        client, err = safe(mongo_client)
        if err:
            st.error(f"Cannot reach mongos router: {err}")
        else:
            shards, err = safe(mgm.get_shard_list, client)
            if err:
                st.warning(err)
            else:
                st.metric("Registered shards", len(shards))

# ===========================================================================
# TAB 2 — PostgreSQL Slow Queries
# ===========================================================================
with tabs[1]:
    st.subheader("Top queries by mean execution time (pg_stat_statements)")
    conn, err = safe(pg_primary)
    if err:
        st.error(err)
    else:
        limit = st.slider("Rows to show", 5, 50, 20)
        df, err = safe(pgm.get_slow_queries, conn, limit)
        if err:
            st.error(err)
        elif df.empty:
            st.info("No query stats yet — run some queries against the `datavault` DB first.")
        else:
            st.dataframe(df, use_container_width=True, height=420)
            fig = px.bar(df.head(10), x="mean_ms", y="query", orientation="h",
                         title="Slowest queries (mean ms)", height=400)
            fig.update_layout(yaxis={"categoryorder": "total ascending"})
            st.plotly_chart(fig, use_container_width=True)

        if st.button("Reset pg_stat_statements counters"):
            pgm.reset_query_stats(conn)
            st.success("Counters reset.")
            st.rerun()

    st.divider()
    st.subheader("Run EXPLAIN on a custom query")
    default_q = (
        "SELECT * FROM orders WHERE customer_email = 'user42@example.com' "
        "AND status = 'shipped';"
    )
    query_text = st.text_area("SQL (SELECT only)", value=default_q, height=100)
    analyze = st.checkbox("Use EXPLAIN ANALYZE (actually runs the query)", value=False)
    if st.button("Explain query"):
        try:
            plan = qo.explain_query(conn, query_text, analyze=analyze)
            st.json(plan)
            recs = qo.recommend_indexes_from_plan(plan)
            if recs:
                st.success(f"Found {len(recs)} index recommendation(s):")
                for r in recs:
                    st.code(r["ddl"], language="sql")
                    st.caption(
                        f"Table `{r['table']}` — filter `{r['filter_clause']}` — "
                        f"{r['rows_removed_by_filter']} rows discarded by the filter"
                    )
            else:
                st.info("No sequential scans with a filter clause were found in this plan.")
        except Exception as e:
            st.error(str(e))

# ===========================================================================
# TAB 3 — Index Recommendations (cluster-wide heuristic scan)
# ===========================================================================
with tabs[2]:
    st.subheader("Tables with a high sequential-scan footprint")
    conn, err = safe(pg_primary)
    if err:
        st.error(err)
    else:
        df, err = safe(pgm.get_missing_index_candidates, conn)
        if err:
            st.error(err)
        elif df is None or df.empty:
            st.success("No obvious missing-index candidates detected right now.")
        else:
            st.dataframe(df, use_container_width=True)
            st.markdown("#### Suggested DDL")
            for _, row in df.iterrows():
                rec = qo.recommend_indexes_for_table(
                    row["table_name"], row["seq_scan"], row["seq_tup_read"], row["n_live_tup"]
                )
                st.code(rec["suggested_ddl"], language="sql")
                st.caption(f"Severity: **{rec['severity']}** — {rec['note']}")

# ===========================================================================
# TAB 4 — Replication Lag
# ===========================================================================
with tabs[3]:
    st.subheader("Streaming replication lag (measured on the primary)")
    conn, err = safe(pg_primary)
    if err:
        st.error(err)
    else:
        df, err = safe(pgm.get_replication_lag, conn)
        if err:
            st.error(err)
        elif df is None or df.empty:
            st.warning("No replicas are currently streaming from the primary.")
        else:
            st.dataframe(df, use_container_width=True)
            fig = px.bar(df, x="application_name", y="replay_lag_seconds",
                         title="Replay lag (seconds) per replica", height=350)
            st.plotly_chart(fig, use_container_width=True)

            fig2 = px.bar(df, x="application_name",
                          y=["sent_lag_bytes", "write_lag_bytes", "flush_lag_bytes", "replay_lag_bytes"],
                          barmode="group", title="WAL lag by stage (bytes)", height=350)
            st.plotly_chart(fig2, use_container_width=True)

    st.info(
        "To see real lag, run `scripts/generate_load.sh` in one terminal while "
        "watching this tab auto-refresh — or use the failover demo in the Runbook tab."
    )

# ===========================================================================
# TAB 5 — MongoDB Shard Balance
# ===========================================================================
with tabs[4]:
    st.subheader("Chunk distribution across shards")
    client, err = safe(mongo_client)
    if err:
        st.error(err)
    else:
        colls, err = safe(mgm.get_sharded_collections, client)
        namespaces = list(colls["_id"]) if (colls is not None and not colls.empty) else []
        ns_choice = st.selectbox("Sharded collection", ["(all)"] + namespaces)
        ns = None if ns_choice == "(all)" else ns_choice

        df, err = safe(mgm.get_chunk_balance, client, ns)
        if err:
            st.error(err)
        elif df is None or df.empty:
            st.info("No chunk metadata yet — has the cluster finished initializing?")
        else:
            st.dataframe(df, use_container_width=True)
            fig = px.pie(df, names="shard", values="chunk_count",
                         title=f"Chunk share {'(' + ns_choice + ')' if ns else '(all collections)'}")
            st.plotly_chart(fig, use_container_width=True)

        balancer, err = safe(mgm.get_balancer_state, client)
        if balancer:
            st.caption(f"Balancer enabled: **{balancer.get('enabled')}**, mode: **{balancer.get('mode')}**")

# ===========================================================================
# TAB 6 — MongoDB Server Status
# ===========================================================================
with tabs[5]:
    st.subheader("serverStatus() summary")
    client, err = safe(mongo_client)
    if err:
        st.error(err)
    else:
        status, err = safe(mgm.get_server_status, client)
        if err:
            st.error(err)
        else:
            c1, c2, c3 = st.columns(3)
            c1.metric("Current connections", status.get("connections", {}).get("current", "n/a"))
            c2.metric("Uptime (s)", int(status.get("uptime", 0)))
            ops = status.get("opcounters", {})
            c3.metric("Total ops (insert+query+update+delete)",
                      sum(ops.get(k, 0) for k in ("insert", "query", "update", "delete")))
            with st.expander("Raw serverStatus() output"):
                st.json({k: status[k] for k in list(status)[:25]})

    st.divider()
    st.subheader("Per-shard replica set health")
    shard_map = {
        "shard1RS": ("mongo-shard1", 27018),
        "shard2RS": ("mongo-shard2", 27018),
        "shard3RS": ("mongo-shard3", 27018),
    }
    pick = st.selectbox("Shard replica set", list(shard_map.keys()))
    host, port = shard_map[pick]
    df, err = safe(mgm.get_replica_set_status, mongo_client(), host, port, pick)
    if err:
        st.error(err)
    elif df is not None and not df.empty:
        st.dataframe(df, use_container_width=True)

# ===========================================================================
# TAB 7 — Runbook
# ===========================================================================
with tabs[6]:
    st.subheader("Operational runbooks")
    runbook_dir = "/app/runbook" if os.path.isdir("/app/runbook") else os.path.join(
        os.path.dirname(__file__), "..", "runbook"
    )
    for fname in ["BACKUP_PITR_RUNBOOK.md", "FAILOVER_DEMO.md"]:
        path = os.path.join(runbook_dir, fname)
        st.markdown(f"### {fname}")
        if os.path.exists(path):
            with open(path) as f:
                st.markdown(f.read())
        else:
            st.warning(f"{fname} not found at {path}")
        st.divider()
