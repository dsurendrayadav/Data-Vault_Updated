"""
pg_monitor.py
PostgreSQL monitoring helpers for the DataVault dashboard.

Everything here reads from:
  - pg_stat_statements   (slow query identification)
  - pg_stat_replication  (replication lag, on the primary)
  - pg_stat_user_tables  (seq scan vs index scan ratios, for index advice)
  - pg_stat_wal_receiver (lag as seen from a replica, if queried directly)
"""

import os
import psycopg2
import psycopg2.extras
import pandas as pd


def _connect(host, port, dbname, user, password):
    return psycopg2.connect(
        host=host, port=port, dbname=dbname, user=user, password=password,
        connect_timeout=3,
    )


def get_primary_conn():
    return _connect(
        os.environ.get("PG_PRIMARY_HOST", "localhost"),
        os.environ.get("PG_PRIMARY_PORT", 5432),
        os.environ.get("PG_DATABASE", "datavault"),
        os.environ.get("PG_USER", "datavault"),
        os.environ.get("PG_PASSWORD", "datavault"),
    )


def get_replica_conns():
    """Returns {node_name: connection} for every replica in PG_REPLICA_HOSTS."""
    raw = os.environ.get("PG_REPLICA_HOSTS", "")
    conns = {}
    for entry in filter(None, raw.split(",")):
        host, port = entry.split(":")
        try:
            conns[host] = _connect(
                host, port,
                os.environ.get("PG_DATABASE", "datavault"),
                os.environ.get("PG_USER", "datavault"),
                os.environ.get("PG_PASSWORD", "datavault"),
            )
        except Exception as e:
            conns[host] = None
    return conns


def run_df(conn, sql, params=None):
    """Run a query and return a pandas DataFrame."""
    return pd.read_sql(sql, conn, params=params)


# ---------------------------------------------------------------------------
# Slow query identification
# ---------------------------------------------------------------------------
SLOW_QUERIES_SQL = """
SELECT
    query,
    calls,
    round(total_exec_time::numeric, 2)  AS total_ms,
    round(mean_exec_time::numeric, 2)   AS mean_ms,
    round(max_exec_time::numeric, 2)    AS max_ms,
    rows,
    round(
        (100 * total_exec_time / NULLIF(sum(total_exec_time) OVER (), 0))::numeric, 2
    ) AS pct_total_time
FROM pg_stat_statements
WHERE query NOT ILIKE '%pg_stat_statements%'
ORDER BY mean_exec_time DESC
LIMIT %(limit)s;
"""


def get_slow_queries(conn, limit=25):
    return run_df(conn, SLOW_QUERIES_SQL, params={"limit": limit})


def reset_query_stats(conn):
    with conn.cursor() as cur:
        cur.execute("SELECT pg_stat_statements_reset();")
    conn.commit()


# ---------------------------------------------------------------------------
# Replication lag (measured from the primary)
# ---------------------------------------------------------------------------
REPLICATION_LAG_SQL = """
SELECT
    application_name,
    client_addr,
    state,
    sync_state,
    pg_wal_lsn_diff(pg_current_wal_lsn(), sent_lsn)   AS sent_lag_bytes,
    pg_wal_lsn_diff(pg_current_wal_lsn(), write_lsn)  AS write_lag_bytes,
    pg_wal_lsn_diff(pg_current_wal_lsn(), flush_lsn)  AS flush_lag_bytes,
    pg_wal_lsn_diff(pg_current_wal_lsn(), replay_lsn) AS replay_lag_bytes,
    EXTRACT(EPOCH FROM replay_lag)  AS replay_lag_seconds
FROM pg_stat_replication;
"""


def get_replication_lag(primary_conn):
    return run_df(primary_conn, REPLICATION_LAG_SQL)


# ---------------------------------------------------------------------------
# Index recommendation: tables with high seq_scan / low idx_scan ratio
# ---------------------------------------------------------------------------
TABLE_SCAN_STATS_SQL = """
SELECT
    schemaname,
    relname AS table_name,
    seq_scan,
    seq_tup_read,
    idx_scan,
    coalesce(idx_scan, 0) + coalesce(seq_scan, 0) AS total_scans,
    n_live_tup
FROM pg_stat_user_tables
ORDER BY seq_scan DESC;
"""


def get_table_scan_stats(conn):
    return run_df(conn, TABLE_SCAN_STATS_SQL)


def get_missing_index_candidates(conn, seq_scan_threshold=50, seq_tup_read_threshold=100000):
    """
    Heuristic: any table where seq_scan is high AND it is reading a large
    number of tuples per scan (seq_tup_read / seq_scan) relative to the
    table's live row count is a strong candidate for a missing index.
    """
    df = get_table_scan_stats(conn)
    if df.empty:
        return df
    df["avg_tuples_per_seq_scan"] = df.apply(
        lambda r: (r.seq_tup_read / r.seq_scan) if r.seq_scan else 0, axis=1
    )
    candidates = df[
        (df.seq_scan >= seq_scan_threshold) &
        (df.seq_tup_read >= seq_tup_read_threshold)
    ].copy()
    return candidates.sort_values("seq_tup_read", ascending=False)
