"""
mongo_monitor.py
MongoDB monitoring helpers for the DataVault dashboard.

Everything here is read through the mongos router (MONGO_URI) using:
  - db.serverStatus()             -> connections, memory, opcounters
  - config.shards / config.chunks -> chunk distribution per shard (balance)
  - rs.status() equivalent (replSetGetStatus) per shard, for replica health
"""

import os
import pandas as pd
from pymongo import MongoClient


def get_client():
    uri = os.environ.get("MONGO_URI", "mongodb://localhost:27017")
    return MongoClient(uri, serverSelectionTimeoutMS=4000)


def get_server_status(client, db_name="datavault"):
    return client[db_name].command("serverStatus")


def get_shard_list(client):
    """List of shards registered with the cluster (from config.shards)."""
    config_db = client["config"]
    shards = list(config_db.shards.find({}, {"_id": 1, "host": 1, "state": 1}))
    return pd.DataFrame(shards)


def get_chunk_balance(client, namespace=None):
    """
    Returns a DataFrame of chunk counts per shard, optionally filtered to
    one namespace (e.g. 'datavault.events'). This is the core signal for
    the "shard balance" panel — an even distribution across shards means
    the balancer is doing its job.
    """
    config_db = client["config"]
    match = {"ns": namespace} if namespace else {}
    pipeline = [
        {"$match": match},
        {"$group": {"_id": "$shard", "chunk_count": {"$sum": 1}}},
        {"$sort": {"_id": 1}},
    ]
    rows = list(config_db.chunks.aggregate(pipeline))
    return pd.DataFrame(rows).rename(columns={"_id": "shard"})


def get_sharded_collections(client):
    config_db = client["config"]
    return pd.DataFrame(list(config_db.collections.find({"dropped": {"$ne": True}})))


def get_collection_stats(client, db_name, coll_name):
    db = client[db_name]
    return db.command("collStats", coll_name)


def get_balancer_state(client):
    admin = client["admin"]
    try:
        state = client["config"].settings.find_one({"_id": "balancer"})
        running = admin.command("balancerStatus") if hasattr(admin, "command") else None
        return {
            "enabled": (not state.get("stopped", False)) if state else True,
            "mode": state.get("mode", "full") if state else "full",
        }
    except Exception as e:
        return {"enabled": None, "mode": None, "error": str(e)}


def get_replica_set_status(client, host, port, rs_name):
    """
    Connects directly to one shard's replica set (bypassing the router)
    to read replSetGetStatus for per-member replication lag/health.
    """
    direct_uri = f"mongodb://{host}:{port}/?replicaSet={rs_name}&directConnection=true"
    direct_client = MongoClient(direct_uri, serverSelectionTimeoutMS=3000)
    try:
        status = direct_client.admin.command("replSetGetStatus")
        members = []
        primary_optime = None
        for m in status["members"]:
            if m.get("stateStr") == "PRIMARY":
                primary_optime = m["optimeDate"]
        for m in status["members"]:
            lag = None
            if primary_optime and m.get("optimeDate"):
                lag = (primary_optime - m["optimeDate"]).total_seconds()
            members.append({
                "name": m["name"],
                "state": m["stateStr"],
                "health": m["health"],
                "lag_seconds": lag,
            })
        return pd.DataFrame(members)
    finally:
        direct_client.close()
