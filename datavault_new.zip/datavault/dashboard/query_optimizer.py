"""
query_optimizer.py
Given a slow query (from pg_stat_statements) or a table with a bad
seq_scan/idx_scan ratio, this module runs EXPLAIN and produces a concrete
CREATE INDEX recommendation using simple, explainable heuristics:

  1. Run EXPLAIN (FORMAT JSON) on the query.
  2. Walk the plan tree looking for Seq Scan nodes with a Filter condition.
  3. Extract the filtered column(s) from the Filter text.
  4. Recommend a btree index on those columns for the scanned relation.

This is intentionally rule-based (no ML / no external query advisor) so
every recommendation is traceable back to the exact plan node that
triggered it — appropriate for a teaching tool.
"""

import re
import json
import psycopg2.extras


FILTER_COLUMN_RE = re.compile(r'([a-zA-Z_][a-zA-Z0-9_]*)\s*(=|>|<|>=|<=|<>|ANY|LIKE)')


def explain_query(conn, query, analyze=False):
    """Returns the JSON query plan for the given SQL statement."""
    mode = "EXPLAIN (FORMAT JSON, ANALYZE, BUFFERS)" if analyze else "EXPLAIN (FORMAT JSON)"
    with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
        cur.execute(f"{mode} {query}")
        plan = cur.fetchone()[0]
    return plan[0]["Plan"]


def _walk_plan(node, seq_scans):
    if node.get("Node Type") == "Seq Scan":
        seq_scans.append(node)
    for child in node.get("Plans", []):
        _walk_plan(child, seq_scans)


def find_seq_scans(plan):
    seq_scans = []
    _walk_plan(plan, seq_scans)
    return seq_scans


def recommend_indexes_from_plan(plan):
    """
    Returns a list of dicts: {table, columns, reason, ddl}
    for every Seq Scan node found in the plan that has a Filter clause.
    """
    recommendations = []
    for node in find_seq_scans(plan):
        table = node.get("Relation Name")
        filt = node.get("Filter")
        rows_removed = node.get("Rows Removed by Filter", 0)
        if not table or not filt:
            continue
        columns = sorted(set(FILTER_COLUMN_RE.findall(filt)))
        columns = [c[0] for c in columns]
        if not columns:
            continue
        idx_name = f"idx_{table}_{'_'.join(columns)}"
        ddl = f"CREATE INDEX {idx_name} ON {table} ({', '.join(columns)});"
        recommendations.append({
            "table": table,
            "columns": columns,
            "rows_removed_by_filter": rows_removed,
            "filter_clause": filt,
            "ddl": ddl,
        })
    return recommendations


def recommend_indexes_for_table(table_name, seq_scan, seq_tup_read, n_live_tup, sample_columns=None):
    """
    Fallback heuristic when we only have pg_stat_user_tables numbers
    (used for the "Index Recommendations" tab which scans ALL tables,
    not just ones appearing in a single EXPLAIN call).
    """
    ratio = (seq_tup_read / seq_scan) if seq_scan else 0
    severity = "high" if ratio > 0.5 * max(n_live_tup, 1) else "medium"
    cols_hint = sample_columns or ["<frequently_filtered_column>"]
    ddl = f"CREATE INDEX idx_{table_name}_auto ON {table_name} ({', '.join(cols_hint)});"
    return {
        "table": table_name,
        "seq_scan": seq_scan,
        "avg_tuples_per_scan": round(ratio, 1),
        "severity": severity,
        "suggested_ddl": ddl,
        "note": (
            "High seq_scan count reading a large fraction of the table on "
            "every scan. Run EXPLAIN on the actual slow query against this "
            "table to get an exact column-level recommendation."
        ),
    }
