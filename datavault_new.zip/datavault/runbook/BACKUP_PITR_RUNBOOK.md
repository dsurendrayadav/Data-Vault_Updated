# Backup & Point-in-Time Recovery (PITR) Runbook — DataVault PostgreSQL cluster

## 1. Backup strategy

DataVault's `pg-primary` is configured for continuous WAL archiving, which
is the foundation of PITR:

```conf
archive_mode    = on
archive_command = 'test ! -f /var/lib/postgresql/wal_archive/%f && cp %p /var/lib/postgresql/wal_archive/%f'
wal_level       = replica
```

Every completed WAL segment is copied to `/var/lib/postgresql/wal_archive`
(a Docker volume, `pg_wal_archive`) as it's produced. Combined with periodic
**base backups**, this lets us restore the database to *any point in time*
between the oldest retained base backup and the most recent archived WAL
segment — not just to the moment of the last backup.

## 2. Taking a base backup

Run from the repo root:

```bash
./scripts/backup.sh
```

This calls `pg_basebackup` inside the primary container and copies both the
backup and the current WAL archive out to `./backups/base_<timestamp>/`.

Recommended cadence for a real deployment: **one base backup per day**,
WAL archived continuously, base backups retained for at least your desired
recovery window (e.g. 7–30 days).

Manually, the equivalent command is:

```bash
docker exec dv-pg-primary pg_basebackup -U datavault -D /tmp/backup -Fp -Xs -P -c fast
```

- `-Fp` — plain format (directory), easy to inspect/restore
- `-Xs` — stream the WAL needed to make the backup self-consistent
- `-c fast` — force an immediate checkpoint rather than waiting

## 3. Restoring to a point in time

**Never restore over a live primary.** Always restore into a fresh
container/volume, verify the data, and only then cut traffic over.

```bash
./scripts/restore_pitr.sh ./backups/base_20260714_090000 "2026-07-14 09:15:00"
```

Internally this:

1. Starts a scratch `postgres:16` container with an empty data volume.
2. Copies the chosen base backup into `/var/lib/postgresql/data`.
3. Copies the WAL archive into `/var/lib/postgresql/wal_archive`.
4. Writes recovery settings to `postgresql.auto.conf`:

   ```conf
   restore_command       = 'cp /var/lib/postgresql/wal_archive/%f %p'
   recovery_target_time  = '2026-07-14 09:15:00'
   recovery_target_action = 'promote'
   ```

5. Creates `recovery.signal` and starts Postgres, which replays WAL
   segments from the base backup forward until it reaches the target time,
   then promotes itself to a normal read/write server.

Omit the second argument to `restore_pitr.sh` to replay **all** available
WAL (i.e. recover to the most recent consistent state).

## 4. Verifying a restore

```bash
docker logs -f dv-pg-restore        # watch WAL replay progress
docker exec dv-pg-restore psql -U datavault -d datavault -c "SELECT now(), pg_is_in_recovery();"
docker exec dv-pg-restore psql -U datavault -d datavault -c "SELECT count(*) FROM orders;"
```

`pg_is_in_recovery()` returns `f` once the target has been reached and the
server has promoted. Compare row counts / recent timestamps against what
you expect for the chosen recovery target time.

## 5. Testing recovery regularly

A backup you have never restored is not a backup. At minimum:

- After every change to `postgresql.conf` or the archive command, take a
  fresh base backup and do a full test restore.
- Periodically (e.g. monthly) restore the latest backup into a scratch
  environment and run application-level smoke tests against it.

## 6. MongoDB backup (companion procedure)

While PITR above is Postgres-specific, the same cluster also runs
MongoDB. For MongoDB:

```bash
# Full logical backup with oplog capture (enables point-in-time replay)
docker exec dv-mongo-shard1 mongodump --port 27018 --oplog --out /tmp/dump
docker cp dv-mongo-shard1:/tmp/dump ./backups/mongo_shard1_$(date +%Y%m%d)

# Restore, replaying the captured oplog to catch up to a specific point
docker exec dv-mongo-shard1 mongorestore --port 27018 --oplogReplay /tmp/dump
```

Repeat per shard (`shard1RS`, `shard2RS`, `shard3RS`) and for the config
server. For production clusters, prefer filesystem/volume snapshots taken
consistently across all shards plus the config server at (nearly) the same
instant, since `mongodump` is a logical, single-node-at-a-time backup.
