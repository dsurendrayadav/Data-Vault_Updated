# Failover Demo Runbook — DataVault

This walks through simulating an outage on both clusters and observing
automatic/assisted recovery. Run `scripts/failover_demo.sh` to execute all
of this in one shot, or step through it manually below.

## Part 1 — PostgreSQL: primary failure + manual promotion

PostgreSQL streaming replication (as configured here) is **not**
self-healing by default — a replica will not auto-promote itself. This is
intentional for the demo: it makes the manual promotion step visible.
(In production you'd typically layer on a failover manager such as
Patroni, repmgr, or pg_auto_failover for automatic promotion + fencing.)

1. **Check current topology:**
   ```bash
   docker exec dv-pg-primary psql -U datavault -d datavault -c \
     "SELECT application_name, state, sync_state FROM pg_stat_replication;"
   ```
   You should see `replica1` and `replica2` in `state = streaming`.

2. **Simulate the primary going down:**
   ```bash
   docker stop dv-pg-primary
   ```

3. **Promote replica1 to primary:**
   ```bash
   docker exec dv-pg-replica1 gosu postgres pg_ctl promote -D /var/lib/postgresql/data
   ```
   This removes `standby.signal` and lets the node accept writes.

4. **Confirm it's writable:**
   ```bash
   docker exec dv-pg-replica1 psql -U datavault -d datavault -c "SELECT pg_is_in_recovery();"
   # -> f (false) means it's now a normal read/write primary
   ```

5. **Point the application at the new primary** — `localhost:5433` instead
   of `5432` (or update a connection-pooler/DNS entry in a real deployment).

6. **Rebuild the failed node as a new replica** once the old primary comes
   back, so you return to a 3-node topology: wipe its data directory and
   let it re-clone via `pg_basebackup` against the new primary (this is
   exactly what `postgres/replica/entrypoint-replica.sh` automates — point
   `PRIMARY_HOST` at `pg-replica1` and restart the old primary container
   using the replica image).

**What to watch in the dashboard:** the *Replication Lag* tab will show the
lost connection the moment the primary stops, and after promotion you can
point a new dashboard session at port 5433 to see the promoted node
serving traffic with no replicas of its own until step 6 is completed.

## Part 2 — MongoDB: shard replica-set failover

Each shard here is a single-node replica set for the demo's resource
footprint, so this section demonstrates the **mechanism** (stepDown +
automatic election) — add 2 more members per shard (see README) to see a
true no-downtime election.

1. **Check shard1's current primary:**
   ```bash
   docker exec dv-mongo-shard1 mongosh --port 27018 --quiet --eval \
     "rs.status().members.forEach(m => print(m.name + ' -> ' + m.stateStr))"
   ```

2. **Force a step-down** (simulates the primary becoming unavailable for
   writes for 60 seconds, triggering an election among remaining members):
   ```bash
   docker exec dv-mongo-shard1 mongosh --port 27018 --quiet --eval "rs.stepDown(60)"
   ```

3. **Observe the election result:**
   ```bash
   docker exec dv-mongo-shard1 mongosh --port 27018 --quiet --eval \
     "rs.status().members.forEach(m => print(m.name + ' -> ' + m.stateStr))"
   ```
   With only one member, it will briefly show `(not reachable/healthy)`
   before re-electing itself, since there's no other node to take over —
   this is exactly why production shards should run 3-node replica sets.

4. **mongos automatically retries and reroutes** — no manual DNS or config
   change needed. Any in-flight write during the election window returns a
   retryable `NotWritablePrimary` error to the client, which the driver
   (pymongo, in the dashboard) will retry automatically for retryable
   operations.

## Scaling each Mongo shard to a true 3-node replica set

To see a *real*, no-single-point-of-failure election, extend
`docker-compose.yml`: add `mongo-shard1b`, `mongo-shard1c` services running
the same image/command with `--replSet shard1RS`, then update
`mongo/init-shard1.js` to list all three hosts in the `members` array
before calling `rs.initiate()`. Repeat for shard2 and shard3.
