#!/bin/bash
set -e

echo ">>> [primary] creating replication role and enabling pg_stat_statements"

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL
    CREATE ROLE ${REPLICATION_USER} WITH REPLICATION LOGIN PASSWORD '${REPLICATION_PASSWORD}';
    CREATE EXTENSION IF NOT EXISTS pg_stat_statements;
EOSQL

mkdir -p /var/lib/postgresql/wal_archive
chown postgres:postgres /var/lib/postgresql/wal_archive

echo ">>> [primary] init complete"
