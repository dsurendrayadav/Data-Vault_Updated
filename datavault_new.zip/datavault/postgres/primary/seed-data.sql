-- DataVault sample OLTP schema.
-- The 'orders' table is intentionally shipped WITHOUT an index on
-- customer_email or status, so the dashboard's slow-query / index
-- recommendation panel has real seq-scans to detect.

CREATE TABLE IF NOT EXISTS customers (
    customer_id     SERIAL PRIMARY KEY,
    email           TEXT NOT NULL,
    full_name       TEXT NOT NULL,
    signup_date     DATE NOT NULL DEFAULT CURRENT_DATE,
    country         TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS orders (
    order_id        BIGSERIAL PRIMARY KEY,
    customer_id     INTEGER NOT NULL REFERENCES customers(customer_id),
    customer_email  TEXT NOT NULL,       -- deliberately unindexed
    status          TEXT NOT NULL,       -- deliberately unindexed
    order_total     NUMERIC(10,2) NOT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_orders_customer_id ON orders(customer_id);

-- Populate customers
INSERT INTO customers (email, full_name, signup_date, country)
SELECT
    'user' || g || '@example.com',
    'Customer ' || g,
    CURRENT_DATE - (random() * 900)::int,
    (ARRAY['US','IN','UK','DE','BR','CA','AU'])[1 + floor(random() * 7)::int]
FROM generate_series(1, 5000) AS g;

-- Populate ~150k orders so seq scans are visibly slow
INSERT INTO orders (customer_id, customer_email, status, order_total, created_at)
SELECT
    c.customer_id,
    c.email,
    (ARRAY['pending','shipped','delivered','cancelled','refunded'])[1 + floor(random() * 5)::int],
    round((random() * 490 + 10)::numeric, 2),
    now() - (random() * interval '365 days')
FROM generate_series(1, 150000) AS g
JOIN customers c ON c.customer_id = 1 + floor(random() * 5000)::int;

ANALYZE customers;
ANALYZE orders;
