#!/bin/bash
set -e

PGDATA=/var/lib/postgresql/data
export PGPASSWORD="${REPLICATION_PASSWORD}"

echo ">>> [${NODE_NAME}] waiting for primary (${PRIMARY_HOST}) to accept connections..."
until pg_isready -h "${PRIMARY_HOST}" -p 5432 -U "${REPLICATION_USER}" >/dev/null 2>&1; do
  sleep 2
done

if [ -z "$(ls -A "$PGDATA" 2>/dev/null)" ]; then
    echo ">>> [${NODE_NAME}] empty data dir — cloning primary with pg_basebackup"
    pg_basebackup \
        -h "${PRIMARY_HOST}" -p 5432 -U "${REPLICATION_USER}" \
        -D "${PGDATA}" -Fp -Xs -P -R \
        -c fast

    # -R writes standby.signal + primary_conninfo automatically (pg12+),
    # but we re-assert it explicitly so the connection string is exact.
    cat >> "${PGDATA}/postgresql.auto.conf" <<-EOF
	primary_conninfo = 'host=${PRIMARY_HOST} port=5432 user=${REPLICATION_USER} password=${REPLICATION_PASSWORD} application_name=${NODE_NAME}'
	restore_command = 'cp /var/lib/postgresql/wal_archive/%f %p 2>/dev/null || true'
	hot_standby = on
	EOF
    touch "${PGDATA}/standby.signal"
    chown -R postgres:postgres "${PGDATA}"
    chmod 700 "${PGDATA}"
else
    echo ">>> [${NODE_NAME}] existing data dir found, skipping base backup"
fi

echo ">>> [${NODE_NAME}] starting postgres in standby mode"
exec gosu postgres postgres
