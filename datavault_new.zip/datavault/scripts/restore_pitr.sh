#!/bin/bash
# Restores a base backup taken by backup.sh and replays WAL up to a given
# point in time. Run this against a *new*, separate container/volume —
# never over a live primary. See runbook/BACKUP_PITR_RUNBOOK.md.
set -e

BACKUP_DIR=$1        # e.g. ./backups/base_20260714_090000
TARGET_TIME=$2        # e.g. "2026-07-14 09:15:00" (omit for "replay everything")
RESTORE_CONTAINER=dv-pg-restore

if [ -z "$BACKUP_DIR" ]; then
  echo "Usage: $0 <backup_dir> [\"target time\"]"
  exit 1
fi

echo ">>> starting a scratch postgres container for PITR restore"
docker rm -f "$RESTORE_CONTAINER" >/dev/null 2>&1 || true
docker run -d --name "$RESTORE_CONTAINER" \
  -e POSTGRES_PASSWORD=datavault \
  -v pg_restore_data:/var/lib/postgresql/data \
  postgres:16 sleep infinity

echo ">>> copying base backup into the restore container"
docker exec "$RESTORE_CONTAINER" bash -c "rm -rf /var/lib/postgresql/data/*"
docker cp "${BACKUP_DIR}/basebackup_"*/. "${RESTORE_CONTAINER}:/var/lib/postgresql/data"
docker cp "${BACKUP_DIR}/wal_archive" "${RESTORE_CONTAINER}:/var/lib/postgresql/wal_archive"

echo ">>> writing recovery configuration"
docker exec "$RESTORE_CONTAINER" bash -c "cat >> /var/lib/postgresql/data/postgresql.auto.conf <<-EOF
restore_command = 'cp /var/lib/postgresql/wal_archive/%f %p'
$( [ -n "$TARGET_TIME" ] && echo "recovery_target_time = '${TARGET_TIME}'" )
recovery_target_action = 'promote'
EOF
touch /var/lib/postgresql/data/recovery.signal
chown -R postgres:postgres /var/lib/postgresql/data"

echo ">>> starting postgres in recovery mode"
docker exec -d "$RESTORE_CONTAINER" gosu postgres postgres

echo ">>> restore container '$RESTORE_CONTAINER' is replaying WAL."
echo "    Tail progress with: docker logs -f $RESTORE_CONTAINER"
echo "    It will pause/promote at: ${TARGET_TIME:-end of available WAL}"
