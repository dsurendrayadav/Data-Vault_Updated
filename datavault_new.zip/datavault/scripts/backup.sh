#!/bin/bash
# Takes a full base backup of pg-primary for use in point-in-time recovery.
# See runbook/BACKUP_PITR_RUNBOOK.md for the full explanation.
set -e

STAMP=$(date +%Y%m%d_%H%M%S)
OUT_DIR="./backups/base_${STAMP}"
mkdir -p "$OUT_DIR"

echo ">>> taking base backup of dv-pg-primary -> ${OUT_DIR}"
docker exec dv-pg-primary pg_basebackup \
  -U datavault -D /tmp/basebackup_${STAMP} -Fp -Xs -P -c fast

docker cp "dv-pg-primary:/tmp/basebackup_${STAMP}" "$OUT_DIR"
docker exec dv-pg-primary rm -rf "/tmp/basebackup_${STAMP}"

echo ">>> copying WAL archive alongside the base backup"
docker cp dv-pg-primary:/var/lib/postgresql/wal_archive "$OUT_DIR/wal_archive"

echo ">>> backup complete: $OUT_DIR"
echo "Restore instructions: see runbook/BACKUP_PITR_RUNBOOK.md"
