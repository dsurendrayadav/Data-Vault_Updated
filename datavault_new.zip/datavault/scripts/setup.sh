#!/bin/bash
# DataVault — one-command environment bring-up.
set -e

cd "$(dirname "$0")/.."

echo "=================================================================="
echo " DataVault: building and starting the full stack"
echo "=================================================================="
docker compose build
docker compose up -d pg-primary
echo ">>> waiting for pg-primary to become healthy..."
until [ "$(docker inspect -f '{{.State.Health.Status}}' dv-pg-primary 2>/dev/null)" = "healthy" ]; do
  sleep 2
done

docker compose up -d pg-replica1 pg-replica2
docker compose up -d mongo-configsvr mongo-shard1 mongo-shard2 mongo-shard3 mongo-router
docker compose up -d mongo-setup
docker compose up -d dashboard

echo "=================================================================="
echo " Stack is starting. Useful endpoints once containers settle:"
echo "   Dashboard:        http://localhost:8501"
echo "   Postgres primary: localhost:5432  (user=datavault / db=datavault)"
echo "   Postgres replica1:localhost:5433"
echo "   Postgres replica2:localhost:5434"
echo "   Mongo router:     localhost:27017"
echo "=================================================================="
echo "Tail logs with: docker compose logs -f"
