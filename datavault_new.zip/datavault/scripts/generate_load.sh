#!/bin/bash
# Generates continuous write + read load against pg-primary so the
# Replication Lag and Slow Query dashboard tabs have real data to show.
set -e

HOST=${1:-localhost}
PORT=${2:-5432}
export PGPASSWORD=datavault

echo ">>> generating load against ${HOST}:${PORT} (Ctrl+C to stop)"

while true; do
  psql -h "$HOST" -p "$PORT" -U datavault -d datavault -c \
    "INSERT INTO orders (customer_id, customer_email, status, order_total, created_at)
     SELECT c.customer_id, c.email,
            (ARRAY['pending','shipped','delivered','cancelled','refunded'])[1 + floor(random()*5)::int],
            round((random()*490+10)::numeric,2), now()
     FROM customers c ORDER BY random() LIMIT 200;" >/dev/null

  # deliberately un-indexed lookups to keep the slow-query panel populated
  psql -h "$HOST" -p "$PORT" -U datavault -d datavault -c \
    "SELECT * FROM orders WHERE customer_email = 'user$((RANDOM % 5000))@example.com';" >/dev/null

  psql -h "$HOST" -p "$PORT" -U datavault -d datavault -c \
    "SELECT * FROM orders WHERE status = 'shipped' LIMIT 500;" >/dev/null

  sleep 1
done
