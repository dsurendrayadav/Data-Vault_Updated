#!/bin/bash
# Scripted failover demo for both clusters. See runbook/FAILOVER_DEMO.md
# for the narrated, step-by-step version of exactly what this does.
set -e

echo "=================================================================="
echo " PART 1: PostgreSQL primary failover"
echo "=================================================================="
echo ">>> current replication status:"
docker exec dv-pg-primary psql -U datavault -d datavault -c \
  "SELECT application_name, state, sync_state FROM pg_stat_replication;"

echo ">>> killing the primary container to simulate an outage..."
docker stop dv-pg-primary

echo ">>> promoting pg-replica1 to become the new primary..."
docker exec dv-pg-replica1 gosu postgres pg_ctl promote -D /var/lib/postgresql/data

sleep 3
echo ">>> verifying replica1 is now writable:"
docker exec dv-pg-replica1 psql -U datavault -d datavault -c \
  "SELECT pg_is_in_recovery();  -- should now be 'f' (false)"

echo ">>> pg-replica1 is now primary. Point the app / dashboard at localhost:5433."
echo "    (to fully restore the 3-node topology afterwards, rebuild the old"
echo "     primary as a new replica of pg-replica1 — see the runbook)"

echo
echo "=================================================================="
echo " PART 2: MongoDB shard1 replica set failover"
echo "=================================================================="
echo ">>> current shard1RS status:"
docker exec dv-mongo-shard1 mongosh --port 27018 --quiet --eval \
  "rs.status().members.forEach(m => print(m.name + ' -> ' + m.stateStr))"

echo ">>> stepping down the current shard1 primary..."
docker exec dv-mongo-shard1 mongosh --port 27018 --quiet --eval \
  "rs.stepDown(60)" || true

sleep 5
echo ">>> shard1RS status after stepDown:"
docker exec dv-mongo-shard1 mongosh --port 27018 --quiet --eval \
  "rs.status().members.forEach(m => print(m.name + ' -> ' + m.stateStr))"

echo "=================================================================="
echo " Failover demo complete."
echo "=================================================================="
